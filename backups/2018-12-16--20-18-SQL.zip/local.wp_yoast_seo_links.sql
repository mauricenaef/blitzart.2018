/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_yoast_seo_links` VALUES
(19,"http://localhost:3003/wp-admin/",2,0,"external");
