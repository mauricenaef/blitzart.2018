/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_yoast_seo_meta` VALUES
(2,0,0),
(8,0,0),
(16,0,0),
(21,0,0),
(24,0,0),
(32,0,0),
(37,0,0),
(41,0,0),
(43,0,0),
(45,0,0);
