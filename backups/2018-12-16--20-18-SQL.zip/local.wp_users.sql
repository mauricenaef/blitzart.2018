/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_users` VALUES
(1,"maurice","$P$BTMTio25EPl4s6.NyqWv0t2f/VnOQE1","maurice","me@mauricenaef.ch","","2017-10-12 11:47:05","",0,"maurice");
